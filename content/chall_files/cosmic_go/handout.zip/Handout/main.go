package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"

	_ "github.com/mattn/go-sqlite3"
)

const file string = "games.db"

type Game struct {
	Date    time.Time
	GameStr string
	UA      string
}

type GameRecord struct {
	ID        int       `json:"id"`
	Timestamp time.Time `json:"timestamp"`
	Moves     int       `json:"moves"`
}

type GameSql struct {
	db *sql.DB
}

var dbHandler *GameSql

const create string = `
  CREATE TABLE IF NOT EXISTS games (
  id INTEGER NOT NULL PRIMARY KEY,
  time DATETIME NOT NULL,
  game TEXT,
  ua TEXT
);`

func NewGameDbHandler() *GameSql {
	db, err := sql.Open("sqlite3", file)
	if err != nil {
		return nil
	}

	if _, err := db.Exec(create); err != nil {
		return nil
	}
	return &GameSql{
		db: db,
	}
}

func (c *GameSql) InsertGame(game Game) (int, error) {
	res, err := c.db.Exec("INSERT INTO games VALUES(NULL, ?, ?, ?);", game.Date, game.GameStr, game.UA)
	if err != nil {
		return 0, err
	}

	var id int64
	if id, err = res.LastInsertId(); err != nil {
		return 0, err
	}
	return int(id), nil
}

func (c *GameSql) GetAllGames() ([]GameRecord, error) {
	rows, err := c.db.Query("SELECT id, time, game FROM games ORDER BY time DESC")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var games []GameRecord
	for rows.Next() {
		var id int
		var timestamp time.Time
		var gameStr string
		if err := rows.Scan(&id, &timestamp, &gameStr); err != nil {
			return nil, err
		}

		var moves []Move
		if err := json.Unmarshal([]byte(gameStr), &moves); err != nil {
			return nil, err
		}

		games = append(games, GameRecord{
			ID:        id,
			Timestamp: timestamp,
			Moves:     len(moves),
		})
	}

	return games, nil
}

func (c *GameSql) GetGameByID(id int) ([]Move, error) {
	var gameStr string
	err := c.db.QueryRow("SELECT game FROM games WHERE id = ?", id).Scan(&gameStr)
	if err != nil {
		return nil, err
	}

	var moves []Move
	if err := json.Unmarshal([]byte(gameStr), &moves); err != nil {
		return nil, err
	}

	return moves, nil
}

type Move struct {
	ID    int `json:"id"`
	X     int `json:"x"`
	Y     int `json:"y"`
	OWNER int `json:"owner"`
}

var moves = []Move{}
var game = []Move{}
var board = [19][19]Move{}

func homeHandler(c *gin.Context) {
	c.HTML(http.StatusOK, "index.html", gin.H{})
}

func historyHandler(c *gin.Context) {
	c.HTML(http.StatusOK, "history.html", gin.H{})
}

func listGamesHandler(c *gin.Context) {
	games, err := dbHandler.GetAllGames()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to retrieve games"})
		return
	}
	c.JSON(http.StatusOK, games)
}

func getGameHandler(c *gin.Context) {
	idStr := c.Param("id")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid game ID"})
		return
	}

	moves, err := dbHandler.GetGameByID(id)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Game not found"})
		return
	}

	c.JSON(http.StatusOK, moves)
}

func isValidPosition(x, y int) bool {
	return x >= 0 && x < 19 && y >= 0 && y < 19
}

func getStoneOwner(x, y int) int {
	if !isValidPosition(x, y) {
		return -1
	}
	if board[y][x].ID > 0 {
		return board[y][x].OWNER
	}
	return -1
}

func getAdjacentPositions(x, y int) [][2]int {
	return [][2]int{
		{x, y - 1},
		{x + 1, y},
		{x, y + 1},
		{x - 1, y},
	}
}

func hasLiberties(x, y int, visited map[[2]int]bool) bool {
	if !isValidPosition(x, y) || getStoneOwner(x, y) == -1 {
		return false
	}
	pos := [2]int{x, y}
	if visited[pos] {
		return false
	}
	visited[pos] = true
	for _, adj := range getAdjacentPositions(x, y) {
		adjX, adjY := adj[0], adj[1]
		if !isValidPosition(adjX, adjY) {
			continue
		}
		if getStoneOwner(adjX, adjY) == -1 {
			return true
		}
		if getStoneOwner(adjX, adjY) == getStoneOwner(x, y) && hasLiberties(adjX, adjY, visited) {
			return true
		}
	}
	return false
}

func captureStones(playerOwner int) {
	var stonesToCapture [][2]int
	for y := 0; y < 19; y++ {
		for x := 0; x < 19; x++ {
			owner := getStoneOwner(x, y)
			if owner != -1 && owner != playerOwner {
				visited := make(map[[2]int]bool)
				if !hasLiberties(x, y, visited) {
					stonesToCapture = append(stonesToCapture, [2]int{x, y})
				}
			}
		}
	}
	for _, pos := range stonesToCapture {
		x, y := pos[0], pos[1]
		fmt.Printf("Capturing stone at x=%d, y=%d\n", x, y)
		board[y][x] = Move{}
	}
}

func addMoveHandler(c *gin.Context) {
	x, err := strconv.Atoi(c.PostForm("x"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid x coordinate!"})
		return
	}
	y, err := strconv.Atoi(c.PostForm("y"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid y coordinate!"})
		return
	}

	if board[y][x].ID > 0 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid move, piece already there!"})
		return
	}

	board[y][x] = Move{ID: 1, OWNER: len(game) % 2}

	currentPlayer := len(game) % 2
	captureStones(currentPlayer)

	hasLib := hasLiberties(x, y, make(map[[2]int]bool))
	if !hasLib {
		board[y][x] = Move{}
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid move, no liberties!"})
		return
	}

	newMove := Move{
		ID:    len(game) + 1,
		X:     x,
		Y:     y,
		OWNER: currentPlayer,
	}

	fmt.Printf("Made move on: x=%d, y=%d\n", newMove.X, newMove.Y)

	board[y][x] = newMove
	moves = append(moves, newMove)
	game = append(game, newMove)
}

func getMovesHandler(c *gin.Context) {
	var currentMoves []Move
	for y := 0; y < 19; y++ {
		for x := 0; x < 19; x++ {
			if board[y][x].ID > 0 {
				currentMoves = append(currentMoves, board[y][x])
			}
		}
	}
	c.JSON(http.StatusOK, currentMoves)
}

func endGameHandler(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"message": "Game resigned", "winner": (len(game) % 2) - 1})

	gameJSON, err := json.Marshal(game)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to serialize game data"})
		return
	}

	finishedGame := Game{
		Date:    time.Now(),
		GameStr: string(gameJSON),
		UA:      string(c.Request.UserAgent()),
	}

	gameID, err := dbHandler.InsertGame(finishedGame)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save game data"})
		return
	}

	moves = []Move{}
	game = []Move{}
	board = [19][19]Move{}

	c.JSON(http.StatusOK, gin.H{
		"message": "Game resigned and saved",
		"winner":  (len(game) % 2) - 1,
		"gameID":  gameID,
	})
}

func main() {
	dbHandler = NewGameDbHandler()

	r := gin.Default()
	r.LoadHTMLGlob("templates/*")
	r.Static("/assets", "./assets")
	r.GET("/", homeHandler)
	r.GET("/moves", getMovesHandler)
	r.POST("/move", addMoveHandler)
	r.POST("/resign", endGameHandler)

	r.GET("/history", historyHandler)
	r.GET("/games", listGamesHandler)
	r.GET("/games/:id", getGameHandler)

	r.Run(":8080")
}
