qemu-system-i386 -drive file=vmbs,format=raw,index=0,media=disk
