#!/usr/bin/python3 
from secrets import choice
from random import randint
from Crypto.Util.number import getStrongPrime

def get_dnd_str():
    dnd_strs = ["Pluto rolls his die and is super excited", "Pluto rolls his die with indifference", 
                "Pluto really wants to leave now", "Pluto is super tired", "mIScG4Ng", "Pluto hates dicegames",
                "Shouldn't we just play Yatzy instead?", "Can we play cards now?"]

    return choice(dnd_strs)

def roll():
    return choice([1,2,3,4,5,6])

def generate(size):
    q = getStrongPrime(size)
     
    g = randint(1, q-1)
    s = randint(1, q-1)
    
    h = pow(g,s,q)
   
    return q,g,h

def commit(param, x):
    q, g, h = param

    r = randint(1, q-1)

    c = (pow(g,x,q) * pow(h,r,q)) % q
    return c,r

def verify(param, c, r, x):
    q, g, h = param
    return pow(c, (q-1)//2, q) == pow((pow(g,x,q) * pow(h,r,q) % q), (q-1)//2, q)

print("I think, this is what they meant with roll your own crypto")
score = 0

def game():
    global score

    while score < 133.7:
        print("\n\n")
        print(get_dnd_str())

        keygen = generate(1024)
        q,g,h = keygen
        
        print(f"These are my parameters:")
        print(f"{q = }")
        print(f"{g = }")
        print(f"{h = }")
        print("\n\n")
        
        secret_roll = roll()
        c,r = commit(keygen, secret_roll)
        print(f"Here's my commitment, so you'll trust me!")
        print(f"{c = }")

        your_roll = roll()
        dc = input(f"Are you satisfied with your roll: {your_roll} [Y/N/G]: ")
        if dc.lower() == "g":
            print("I'm sorry you don't trust my key generation:(\n")
            print(f"Here's all you need to ensure I didn't cheat:")
            print(f"{c = }")
            print(f"{r = }")

            game()
        elif dc.lower() == "n":
            print("I'm sorry you don't trust that I'm rolling your die fair:(")

            while dc.lower() == "n":
                your_roll = roll()
                dc = input(f"Are you satisfied with your roll: {your_roll} [Y/N]: ")
    
        if verify(keygen, c, r, secret_roll) == verify(keygen, c, r, your_roll):
            score += 1
            print(f"Score increased! New score: {score}")
        else:
            print(f"Sorry you chose poorly. New highscore: {score}\n")
            print(f"Here's all you need to ensure I didn't cheat:")
            print(f"{c = }")
            print(f"{r = }")

            exit()

    with open("flag.txt") as f:
        data = f.read()

    print(f"Here's your flag: {data}")

if __name__ == "__main__":
    game()
